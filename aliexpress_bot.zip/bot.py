import os
import random
import time
import schedule
from telegram import Bot

BOT_TOKEN = os.environ['BOT_TOKEN']
CHANNEL_ID = os.environ['CHANNEL_ID']

bot = Bot(token=BOT_TOKEN)

PRODUCTS = [
    {
        "name": "שעון חכם איכותי",
        "image": "https://ae01.alicdn.com/kf/abc123.jpg",
        "link": "https://s.click.aliexpress.com/deep_link1"
    },
    {
        "name": "אוזניות בלוטות'",
        "image": "https://ae01.alicdn.com/kf/def456.jpg",
        "link": "https://s.click.aliexpress.com/deep_link2"
    },
]

def send_product():
    product = random.choice(PRODUCTS)
    caption = f"{product['name']}\n{product['link']}"
    bot.send_photo(chat_id=CHANNEL_ID, photo=product['image'], caption=caption)

schedule.every().day.at("09:00").do(send_product)
schedule.every().day.at("14:00").do(send_product)
schedule.every().day.at("19:00").do(send_product)

print("הבוט פועל...")

while True:
    schedule.run_pending()
    time.sleep(60)
